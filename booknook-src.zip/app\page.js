
import ExtraSections from "@/components/home/extra-sections";
import HeroSlider from "@/components/home/hero-slider";
import NewArrivals from "@/components/home/new-arrivals";
import ScrollReveal from "@/components/scroll-reveal";

export default function Home() {
  return (
    <div>
      {/* Hero Section */}
      <ScrollReveal direction="up">
        <HeroSlider />
      </ScrollReveal>

      {/* New Arrivals Section */}
      <ScrollReveal direction="up" delay={0.15}>
        <NewArrivals />
      </ScrollReveal>

      {/* Extra Sections */}
      <ScrollReveal direction="up" delay={0.2}>
        <ExtraSections />
      </ScrollReveal>
    </div>
  );
}
